<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Form Biodata Mahasiswa</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
</head>
<body>
	<div class="container mt-5">
		<h1>BIODATA MAHASISWA</h1>
		<h5>Silahkan masukkan data diri anda dibawah ini.</h5>
		<hr align="left" width="50%">
		<form class="mt-4" action="home.php" method="post">
			<div class="form-group row">
				<div class="col">
				    <label>Nama Depan</label>
				    <input type="text" name="nama_depan" class="form-control" placeholder="Masukkan nama depan" required>
				</div>
				<div class="col">
					<label>Nama Belakang</label>
				    <input type="text" name="nama_belakang" class="form-control" placeholder="Masukkan nama belakang" required>
				</div>
		  	</div>
		  	<div class="form-group">
		  		<label>Jenis Kelamin</label>
		  		<br>
				<div class="form-check form-check-inline">
			  		<input class="form-check-input" type="radio" name="jenis_kelamin" id="laki-laki" value="Laki-laki" checked>
			  		<label class="form-check-label" for="laki-laki">Laki-laki</label>
				</div>
				<div class="form-check form-check-inline">
			  		<input class="form-check-input" type="radio" name="jenis_kelamin" id="perempuan" value="Perempuan">
			  		<label class="form-check-label" for="perempuan">Perempuan</label>
				</div>
		  	</div>
		  	<div class="form-group row">
				<div class="col-md-10">
				    <label>Tempat Lahir</label>
				    <input type="text" name="tempat_lahir" class="form-control" placeholder="Masukkan tempat lahir" required>
				</div>
				<div class="col-md-2">
					<label>Tanggal Lahir</label>
				    <input type="date" name="tanggal_lahir" class="form-control" placeholder="Masukkan tanggal lahir" required>
				</div>
		  	</div>
		  	<div class="form-group">
		  		<label>Agama</label>
		  		<select class="form-control" name="agama">
		  			<option value="Islam">Islam</option>
		  			<option value="Kristen">Kristen</option>
		  			<option value="Hindu">Hindu</option>
		  			<option value="Budha">Budha</option>
		  			<option value="Konghucu">Konghucu</option>
		  			<option value="Ateis">Ateis</option>
		  		</select>
		  	</div>
		  	<div class="form-group">
		  		<label>Alamat Lengkap</label>
		  		<textarea class="form-control" name="alamat" rows="3" placeholder="Masukkan alamat tempat tinggal" required></textarea>
		  	</div>
		  	<button type="submit" class="btn btn-primary float-right">Simpan</button>
		</form>
	</div>
</body>
</html>
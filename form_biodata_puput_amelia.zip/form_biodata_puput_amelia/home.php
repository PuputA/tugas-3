<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Biodata <?php echo $_POST["nama_depan"]; ?></title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
</head>
<body>
	<div class="container mt-5">
		<div class="card text-center">
	  		<div class="card-header">
	    		Biodata <?php echo $_POST["nama_depan"]; ?>
	  		</div>
	  		<div class="card-body">
	    		<h5 class="card-title">Hai, <?php echo $_POST["nama_depan"]; ?>.</h5>
	    		<p>Berikut ini biodata yang telah anda isi pada halaman sebelumnya.</p>
	    		<p class="card-text">Nama Lengkap : <?php echo $_POST["nama_depan"] . ' ' . $_POST["nama_belakang"]; ?></p>
	    		<p class="card-text">Jenis Kelamin : <?php echo $_POST["jenis_kelamin"]; ?></p>
	    		<p class="card-text">Tempat Lahir : <?php echo $_POST["tempat_lahir"]; ?></p>
	    		<p class="card-text">Tanggal Lahir : <?php echo $_POST["tanggal_lahir"]; ?></p>
	    		<p class="card-text">Agama : <?php echo $_POST["agama"]; ?></p>
	    		<p class="card-text">Alamat : <?php echo $_POST["alamat"]; ?></p>
	  		</div>
  			<div class="card-footer text-muted">
	    		By Puput Amelia
	  		</div>
		</div>
  		<a href="index.php" class="btn btn-primary mt-3">Kembali</a>
	</div>
</body>
</html>